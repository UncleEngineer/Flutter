#serializers.py
from rest_framework import serializers
from .models import allproduct

class AllproductSerializer(serializers.ModelSerializer):
	class Meta:
		model = allproduct
		fields = ('id','name','price','quan','desc')