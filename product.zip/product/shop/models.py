from django.db import models

# Create your models here.
class allproduct(models.Model):
	name = models.CharField(max_length=100,verbose_name='ชื่อสินค้า')
	price = models.IntegerField(default=10,blank=True,null=True,verbose_name='ราคา')
	quan = models.IntegerField(blank=True,null=True,verbose_name='จำนวน')
	desc = models.TextField(blank=True,null=True,verbose_name='รายละเอียด')

	def __str__(self):
		return self.name