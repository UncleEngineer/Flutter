from django.urls import path
from .views import (Home,
					About,
					AllproductAPI,
					AllproductAPIDetail,
					api_post_product)

urlpatterns = [
    path('',Home),
    path('allproduct/',About,name='about-page'),
    path('api/',AllproductAPI, name='product-api'),
    path('api/<int:pk>/<str:password>',AllproductAPIDetail),
    path('api/post',api_post_product)

]
