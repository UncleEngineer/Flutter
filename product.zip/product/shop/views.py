from django.shortcuts import render
from django.http import HttpResponse
from .models import allproduct

# Create your views here.
def Home(request):
	return render(request,'shop/home.html')

def About(request):
	products = allproduct.objects.all()
	context = {'products':products}
	return render(request,'shop/about.html',context)

from .serializers import AllproductSerializer
from django.http import JsonResponse

def AllproductAPI(request):
	product = allproduct.objects.all()
	serializer = AllproductSerializer(product,many=True)
	return JsonResponse(serializer.data, safe=False, json_dumps_params={'ensure_ascii':False})

def AllproductAPIDetail(request,pk,password):
	product = allproduct.objects.get(id=pk)
	serializer = AllproductSerializer(product)

	if password=='999':
		finaldata = serializer.data
		finaldata['admin'] = 'Somchai'
	else:
		finaldata = {'status':'password failed'}
	return JsonResponse(finaldata, json_dumps_params={'ensure_ascii':False})
	#return JsonResponse(serializer.data, json_dumps_params={'ensure_ascii':False})


from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status

@api_view(['POST'])
def api_post_product(request):
	if request.method == 'POST':
		serializer = AllproductSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return Response(serializer.data, status=status.HTTP_201_CREATED)
		return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)